///
/// @file student.c
/// @author Felix Fong
/// @date 2022-04-8
/// @copyright (c) 2022
///
/// Contains the struct Student along with helper functions
/// to perform operations on the struct.
///

/**
 * Data struct of a student containing their name, student id,
 * and a list of their grades in school.
 */
typedef struct _student {
    char first_name[50];
    char last_name[50];
    char id[11];
    double* grades;
    int num_grades;
} Student;

// Helper functions for Student.

void add_grade (Student* student, double grade);

double average (Student* student);

void print_student (Student* student);

Student* generate_random_student (int grades);
