///
/// @file student.c
/// @author Felix Fong
/// @date 2022-04-8
/// @copyright (c) 2022
///
/// Contains implementations of helper functions for the Student struct.
///

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Add an additional grade to the list of a Student's grades.
 * @param student - The student who's grades will be updated.
 * @param grade - The additional grade given to the student.
 */
void add_grade (Student* student, double grade) {
    student->num_grades++;

    // If a student didn't have any grades before, initialize their grades list
    if (student->num_grades==1) {
        student->grades = calloc(1, sizeof(double));

    // Otherwise, reallocate their list to a new list with one additional space
    } else {
        student->grades =
                realloc(student->grades, sizeof(double)*student->num_grades);
    }

    // Assign the new space to the specified grade
    student->grades[student->num_grades-1] = grade;
}

/**
 * @param student
 * @return the average grade in a student's grades list
 */
double average (Student* student) {
    // Default to 0 if a student doesn't have any grades
    if (student->num_grades==0) return 0;

    // Find the total of the student's grades
    double total = 0;
    for (int i = 0; i<student->num_grades; i++) total += student->grades[i];

    // Calculate the average grade
    return total/((double) student->num_grades);
}

/**
 * Prints a student's name, ID, grades, and grade average.
 * @param student - the student who's data will be printed
 */
void print_student (Student* student) {
    printf("Name: %s %s\n", student->first_name, student->last_name);
    printf("ID: %s\n", student->id);
    printf("Grades: ");

    // Print the student's grades in one line.
    for (int i = 0; i<student->num_grades; i++)
        printf("%.2f ", student->grades[i]);
    printf("\n");

    printf("Average: %.2f\n\n", average(student));
}

/**
 * @param grades - The number of grades the student will have
 * @return a student with randomized data and a name created from a pool of 24 first
 * and last names
 */
Student* generate_random_student (int grades) {
    char first_names[][24] =
            {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
             "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
             "Julie", "Omar", "Yousef", "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

    char last_names[][24] =
            {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams",
             "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat",
             "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

    Student* new_student = calloc(1, sizeof(Student));

    // Choose random first and last names for the student
    strcpy(new_student->first_name, first_names[rand()%24]);
    strcpy(new_student->last_name, last_names[rand()%24]);

    // Randomize each digit in a student's ID.
    for (int i = 0; i<10; i++) {
        // Assign a digit of the id an int from 0-9 mapped to its char counterpart
        new_student->id[i] = (char) ((rand()%10)+'0');
    }
    new_student->id[10] = '\0';

    // Give a student "grades" random grades from 25-100
    for (int i = 0; i<grades; i++) {
        add_grade(new_student, (double) (25+(rand()%75)));
    }

    return new_student;
}