///
/// @file student.c
/// @author Felix Fong
/// @date 2022-04-8
/// @copyright (c) 2022
///
/// Contains implementations of helper functions for the Course struct.
///

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Enroll a student in a course
 * @param course - The course the student will enroll in
 * @param student - The specified student
 */
void enroll_student (Course* course, Student* student) {
    course->total_students++;

    // If a course previously had no enrollments, initialize the
    // student enrollment list
    if (course->total_students==1) {
        course->students = calloc(1, sizeof(Student));

        // Otherwise, reallocate its list to a new list with one additional space
    } else {
        course->students =
                realloc(course->students, course->total_students*sizeof(Student));
    }
    course->students[course->total_students-1] = *student;
}

/**
 * Prints a course's name, code, total # of students, and all the students
 * enrolled in the course.
 * @param course
 */
void print_course (Course* course) {
    printf("Name: %s\n", course->name);
    printf("Code: %s\n", course->code);
    printf("Total students: %d\n\n", course->total_students);
    printf("****************************************\n\n");

    // Print all the students in the course.
    for (int i = 0; i<course->total_students; i++)
        print_student(&course->students[i]);
}


/**
 * @param course
 * @return the student with the highest average in the course.
 */
Student* top_student (Course* course) {
    // Default to null if no one's enrolled
    if (course->total_students==0) return NULL;

    double student_average = 0;

    // Initialize the current top student to be the first student
    double max_average = average(&course->students[0]);
    Student* student = &course->students[0];

    // Compare the average of all the students to find the max student.
    // Start at the second student since the first student has already been accounted.
    for (int i = 1; i<course->total_students; i++) {
        student_average = average(&course->students[i]);

        // Update the top student to the current student if the
        // current student has a higher average.
        if (student_average>max_average) {
            max_average = student_average;
            student = &course->students[i];
        }
    }

    return student;
}

/**
 * @param course - The specified course
 * @param total_passing - The number of passing students in a course (used like a return value)
 * @return A list of the passing students in a course.
 */
Student* passing (Course* course, int* total_passing) {
    int count = 0;
    Student* passing = NULL;

    // Count the number of passing students
    for (int i = 0; i<course->total_students; i++) {
        // Increment the counter if a student's average is above 50 (i.e. passing)
        if (average(&course->students[i])>=50) count++;
    }

    // Allocate enough memory to make a list of the passing students
    passing = calloc(count, sizeof(Student));

    // Index to an empty slot in passing
    int j = 0;

    for (int i = 0; i<course->total_students; i++) {
        // Add the student to the list if they're passing.
        if (average(&course->students[i])>=50) {
            passing[j] = course->students[i];

            // Go to the next empty slot
            j++;
        }
    }

    *total_passing = count;

    return passing;
}