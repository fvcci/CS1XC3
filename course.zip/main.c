///
/// @file main.c
/// @author Felix Fong
/// @date 2022-04-8
/// @copyright (c) 2022
///
/// Code to demonstrate the use of the course and student libraries.
///

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main () {
    // Randomize the random seed
    srand((unsigned) time(NULL));

    // Initialize the MATH101 course: Basics of Mathematics
    Course* MATH101 = calloc(1, sizeof(Course));
    strcpy(MATH101->name, "Basics of Mathematics");
    strcpy(MATH101->code, "MATH 101");

    // Enroll 20 randomized students with 8 grades
    for (int i = 0; i<20; i++) {
        enroll_student(MATH101, generate_random_student(8));
    }

    print_course(MATH101);

    // Display the top student in the course
    Student* student;
    student = top_student(MATH101);
    printf("\n\nTop student: \n\n");
    print_student(student);

    // Display the number and list of students passing the course
    int total_passing;
    Student* passing_students = passing(MATH101, &total_passing);
    printf("\nTotal passing: %d\n", total_passing);
    printf("\nPassing students:\n\n");
    for (int i = 0; i<total_passing; i++) {
        print_student(&passing_students[i]);
    }

    return 0;
}