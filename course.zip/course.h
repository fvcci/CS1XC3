///
/// Felix Fong
/// April 8, 2022
///
/// Contains the struct Course along with helper functions
/// to perform operations on the struct.
///

#include "student.h"
#include <stdbool.h>

/**
 * Data struct of a school course containing its name, course code,
 * and students enrolled in the course.
 */
typedef struct _course {
    char name[100];
    char code[10];
    Student* students;
    int total_students;
} Course;

// Helper functions for Course.

void enroll_student (Course* course, Student* student);

void print_course (Course* course);

Student* top_student (Course* course);

Student* passing (Course* course, int* total_passing);


